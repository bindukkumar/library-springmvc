package com.capgemini.libraryspringmvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.libraryspringmvc.beans.Book;
@Repository
public class BookDaoImpl implements BookDao {
private static EntityManagerFactory entityManagerFactory =Persistence.createEntityManagerFactory("TestPersistence");

public Book addBook(Book book) {
		try {
			EntityManager entityManager =entityManagerFactory.createEntityManager();
			EntityTransaction entityTransaction =entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.persist(book);
			entityTransaction.commit();
			entityManager.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return book;
	}

	public boolean updateBook(int bookId ) {
		try {
			Book book =new Book();
			EntityManager entityManager =entityManagerFactory.createEntityManager();
			EntityTransaction entityTransaction =entityManager.getTransaction();
			Book book1=entityManager.find(Book.class,book.getBookId());
			if(book1!=null) {
				entityTransaction.begin();
				book1.setBookName(book.getBookName());
				book1.setBookAuthor(book.getBookAuthor());
				book1.setBookPublisher(book.getBookPublisher());
				entityTransaction.commit();
				entityManager.close();
				return true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public boolean deleteBook(int bookId) {
		try {
		EntityManager entityManager =entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction =entityManager.getTransaction();
		Book book=entityManager.find(Book.class, bookId);
		entityTransaction.begin();
		entityManager.remove(book);
		entityTransaction.commit();
		entityManager.close();
		return true;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public List<Book> getAllbook() {
		List<Book> books=null;
		try {
			EntityManager entityManager =entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			TypedQuery<Book> query =entityManager.createQuery("FROM Book",Book.class);
			books =query.getResultList();
			entityManager.getTransaction().commit();
			entityManager.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return books;
	}

	public List<Book> SearchBook(int bookId) {
			List<Book> books=null;
			EntityManager entityManager =entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			TypedQuery<Book> query =entityManager.createQuery("FROM Book",Book.class);
			books =query.getResultList();
			entityManager.getTransaction().commit();
			entityManager.close();
			return books;
		
		}
		
	
	}


