package com.capgemini.libraryspringmvc.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Library {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int libId;
	private int libName;
	

	public int getLibId() {
		return libId;
	}
	public void setLibId(int libId) {
		this.libId = libId;
	}
	public int getLibName() {
		return libName;
	}
	public void setLibName(int libName) {
		this.libName = libName;
	}

	@Override
	public String toString() {
		return "Library [libId=" + libId + ", libName=" + libName + "]";
	}
}
